Iris EXIFeditor
===============

ΕΛΛΗΝΙΚΑ

Βοηθός φωτογραφιών για Mac. Ετοιμάζει τις φωτογραφίες σου πριν μπουν στο Apollo.

Σύντομη περιγραφή
Εφαρμογή για Mac που διορθώνει ημερομηνία και τοποθεσία, γράφει τίτλους και λέξεις-κλειδιά, μετονομάζει αρχεία και βρίσκει διπλότυπες φωτογραφίες.

Μεγάλη περιγραφή
Το Iris είναι εφαρμογή για Mac που ετοιμάζει τις φωτογραφίες σου πριν μπουν στο αρχείο σου. Διορθώνει ημερομηνία λήψης και τοποθεσία, γράφει τίτλο, περιγραφή και λέξεις-κλειδιά, μετονομάζει μαζικά τα αρχεία και εντοπίζει τα διπλότυπα.

Όλη η επεξεργασία γίνεται τοπικά, μέσα στο sandbox της Apple, χωρίς να ανεβαίνει τίποτα πουθενά. Είναι ο φυσικός σύντροφος του Apollo: ό,τι τακτοποιεί το Iris, το Apollo το δείχνει σωστά σε άλμπουμ, χάρτη και ταξίδια.

Developer: dimakis
Συσκευές: Mac
Γλώσσες: 32
Τιμή: Θα ανακοινωθεί
Κυκλοφορία: Έρχεται σύντομα
Σελίδα: https://dimakis.app/iris/
Επικοινωνία για τύπο: press@dimakis.app


ENGLISH

Photo companion for Mac. Gets your photos ready before they join Apollo.

Short description
A Mac app that fixes dates and locations, writes titles and keywords, renames files and finds duplicate photos, all locally on your Mac.

Long description
Iris is a Mac app that gets your photos ready before they join your library. It fixes capture dates and locations, writes titles, descriptions and keywords, bulk-renames files and finds duplicates.

Everything happens locally, inside Apple's sandbox, with nothing uploaded anywhere. It's the natural companion to Apollo: whatever Iris tidies up, Apollo shows correctly in albums, on the map and in trips.

Developer: dimakis
Platforms: Mac
Languages: 32
Price: To be announced
Release: Coming soon
Website: https://dimakis.app/en/iris/
Press contact: press@dimakis.app

Apple, the Apple logo, iPhone, iPad, Mac and Apple Watch are trademarks of Apple Inc.
