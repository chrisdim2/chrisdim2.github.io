Apollo Cloud Photo Gallery
==========================

ΕΛΛΗΝΙΚΑ

Οικογενειακό άλμπουμ φωτογραφιών. Φως στις αναμνήσεις.

Σύντομη περιγραφή
Οικογενειακό άλμπουμ που δουλεύει πάνω στο δικό σου cloud: άλμπουμ ανά έτος, χάρτης, ταξίδια και έξυπνη αναζήτηση, μόνο μέσα στη συσκευή.

Μεγάλη περιγραφή
Το Apollo είναι οικογενειακό άλμπουμ φωτογραφιών για iPhone, iPad και Mac που δεν αντιγράφει τίποτα. Δουλεύει απευθείας πάνω στις φωτογραφίες που έχεις ήδη στο pCloud, στο Dropbox, στο OneDrive και σε άλλες υπηρεσίες, και τις οργανώνει σε άλμπουμ ανά έτος και σε χάρτη, με τις πραγματικές ημερομηνίες και τοποθεσίες λήψης.

Η έξυπνη ανάλυση γίνεται μόνο μέσα στη συσκευή: γράφεις «θάλασσα» ή «σκύλος» και βρίσκει τις φωτογραφίες, διαλέγει τα καλύτερα εξώφυλλα και εντοπίζει τις διπλές. Τα ταξίδια βγαίνουν μόνα τους από τις φωτογραφίες σου, μαζί με κάρτες επιβίβασης, ακτοπλοϊκά εισιτήρια και στατιστικά χιλιομέτρων και χωρών.

Με το Family mode, όλη η οικογένεια βλέπει τα ίδια εξώφυλλα, φακέλους και ταξίδια, πάνω στο ίδιο cloud.

Developer: dimakis
Συσκευές: iPhone, iPad, Mac
Γλώσσες: 32
Τιμή: Θα ανακοινωθεί
Κυκλοφορία: Έρχεται σύντομα
Σελίδα: https://dimakis.app/apollo/
Επικοινωνία για τύπο: press@dimakis.app


ENGLISH

Family photo album. Light on your memories.

Short description
A family photo album that works right on your own cloud: albums by year, a map, automatic trips and smart search, all on your device.

Long description
Apollo is a family photo album for iPhone, iPad and Mac that doesn't copy anything. It works directly on the photos you already keep in pCloud, Dropbox, OneDrive and other services, and organises them into albums by year and on a map, using the real capture dates and locations.

Smart analysis runs on your device only: type “sea” or “dog” to find photos, let it pick the best covers and spot duplicates. Trips are detected automatically from your photos, alongside boarding passes, ferry tickets and distance and country stats.

With Family mode, everyone in the family sees the same covers, folders and trips, on the same cloud.

Developer: dimakis
Platforms: iPhone, iPad, Mac
Languages: 32
Price: To be announced
Release: Coming soon
Website: https://dimakis.app/en/apollo/
Press contact: press@dimakis.app

Apple, the Apple logo, iPhone, iPad, Mac and Apple Watch are trademarks of Apple Inc.
