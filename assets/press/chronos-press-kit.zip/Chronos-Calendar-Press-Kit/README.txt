Chronos Calendar
================

ΕΛΛΗΝΙΚΑ

Ημερολόγιο. Ο χρόνος υπό τον έλεγχό σου.

Σύντομη περιγραφή
Ημερολόγιο για iPhone, iPad, Mac και Apple Watch με αντίστροφη μέτρηση, υπενθυμίσεις φαρμάκων, συντήρηση αυτοκινήτου και εφημερεύοντα φαρμακεία.

Μεγάλη περιγραφή
Το Chronos είναι ημερολόγιο για iPhone, iPad, Mac και Apple Watch που δεν σταματά στα ραντεβού. Δείχνει τον μήνα, την εβδομάδα, την ημέρα, το έτος ή μια λίστα, με τον καιρό κάθε ημέρας δίπλα στα γεγονότα, και καταλαβαίνει ό,τι γράφεις όπως θα το έλεγες.

Μαζεύει σε ένα μέρος όσα συνήθως σκορπίζονται σε σημειώσεις και υπενθυμίσεις: αντίστροφη μέτρηση για γενέθλια και ταξίδια, που μπορείς να τη στείλεις σε φίλο, φάρμακα με έλεγχο αλληλεπιδράσεων, service, ΚΤΕΟ και ασφάλεια του αυτοκινήτου, δάνεια, συνδρομές και συντήρηση του σπιτιού.

Για την Ελλάδα έχει κάτι που δεν έχει κανένα ξένο ημερολόγιο: γιορτές και εφημερεύοντα φαρμακεία και νοσοκομεία κοντά σου, σε πραγματικό χρόνο. Τα δεδομένα σου μένουν στη συσκευή και στο iCloud σου.

Developer: dimakis
Συσκευές: iPhone, iPad, Mac, Apple Watch
Γλώσσες: 32
Τιμή: Θα ανακοινωθεί
Κυκλοφορία: Έρχεται τον Δεκέμβριο
Σελίδα: https://dimakis.app/chronos/
Επικοινωνία για τύπο: press@dimakis.app


ENGLISH

Calendar. Your time, under control.

Short description
A calendar for iPhone, iPad, Mac and Apple Watch with countdowns, medication reminders, car maintenance tracking and nearby on-duty pharmacies.

Long description
Chronos is a calendar for iPhone, iPad, Mac and Apple Watch that goes beyond appointments. It shows your month, week, day, year or a simple list, with each day's weather right next to your events, and understands what you type the way you'd say it.

It brings together everything that usually ends up scattered across notes and reminders: countdowns for birthdays and trips that you can send to a friend, medication with interaction checks, car service, inspections and insurance, loans, subscriptions and home maintenance.

In Greece it does something no other calendar does: name days, plus on-duty pharmacies and hospitals near you, in real time. Your data stays on your devices and in your own iCloud.

Developer: dimakis
Platforms: iPhone, iPad, Mac, Apple Watch
Languages: 32
Price: To be announced
Release: Coming in December
Website: https://dimakis.app/en/chronos/
Press contact: press@dimakis.app

Apple, the Apple logo, iPhone, iPad, Mac and Apple Watch are trademarks of Apple Inc.
